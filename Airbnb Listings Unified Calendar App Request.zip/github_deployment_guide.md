# GitHub Pages Deployment Guide for Airbnb Calendar Integration App

This guide will walk you through deploying your Airbnb Calendar Integration App to GitHub Pages for free static hosting.

## Prerequisites

- A GitHub account
- Git installed on your computer
- Basic knowledge of Git commands

## Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in to your account
2. Click on the "+" icon in the top right corner and select "New repository"
3. Name your repository (e.g., "airbnb-calendar-app")
4. Make the repository public (for GitHub Pages)
5. Click "Create repository"

## Step 2: Prepare Your Application for Deployment

1. Make sure your application is built for static hosting:
   ```bash
   cd airbnb-calendar-app-nextjs
   npm run build
   ```
   This will create a folder called "out" with your static files

2. Create a file called `.nojekyll` in the "out" directory to tell GitHub Pages not to process your files with Jekyll:
   ```bash
   touch out/.nojekyll
   ```

## Step 3: Initialize Git and Push to GitHub

1. Initialize a Git repository in your project folder:
   ```bash
   cd airbnb-calendar-app-nextjs
   git init
   ```

2. Add your GitHub repository as a remote:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/airbnb-calendar-app.git
   ```

3. Create a branch specifically for GitHub Pages:
   ```bash
   git checkout -b gh-pages
   ```

4. Add all files in the "out" directory:
   ```bash
   git add out/
   ```

5. Commit the changes:
   ```bash
   git commit -m "Initial deployment"
   ```

6. Push to GitHub:
   ```bash
   git push -u origin gh-pages
   ```

## Step 4: Configure GitHub Pages

1. Go to your repository on GitHub
2. Click on "Settings"
3. Scroll down to the "GitHub Pages" section
4. Under "Source", select the "gh-pages" branch
5. Click "Save"

Your site will be published at `https://YOUR_USERNAME.github.io/airbnb-calendar-app/`

## Step 5: Access Your Application

1. Wait a few minutes for GitHub Pages to deploy your site
2. Visit `https://YOUR_USERNAME.github.io/airbnb-calendar-app/` in your browser
3. Log in with the password: `airbnb-calendar`

## Updating Your Application

When you make changes to your application:

1. Rebuild your application:
   ```bash
   npm run build
   ```

2. Add and commit the changes:
   ```bash
   git add out/
   git commit -m "Update application"
   ```

3. Push to GitHub:
   ```bash
   git push origin gh-pages
   ```

GitHub Pages will automatically update your site with the new changes.

## Troubleshooting

- If your site shows a 404 error, make sure your repository is public and that GitHub Pages is enabled
- If styles or scripts are not loading, check that the paths in your HTML files are correct
- If you encounter CORS issues with the iCalendar URLs, you may need to use a CORS proxy service
