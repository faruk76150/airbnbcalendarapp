# Airbnb Calendar Integration App - User Guide

## Overview

The Airbnb Calendar Integration App allows you to view all your Airbnb listings in a single unified calendar. This makes it easier to manage multiple properties and avoid scheduling conflicts.

## Features

- **Unified Calendar View**: See all your Airbnb listings in one calendar
- **Listing Management**: Add, edit, and remove Airbnb listings
- **Color Coding**: Each listing has its own color for easy identification
- **Filtering**: Show or hide specific listings as needed
- **Password Protection**: Secure access to your listing information
- **Responsive Design**: Works on desktop and mobile devices

## Getting Started

### Accessing the Application

1. Deploy the application using the instructions in the GitHub deployment guide
2. Access the application at your GitHub Pages URL
3. Log in with the password: `airbnb-calendar`

### Adding Your Airbnb Listings

1. Click on "Add Listing" in the navigation menu
2. Enter the listing details:
   - **Listing Name**: A name to identify your property (e.g., "Beach House")
   - **iCalendar URL**: The iCalendar URL from your Airbnb listing
   - **Display Color**: Choose a color for this listing on the calendar
3. Click "Test Connection" to verify the iCalendar URL is valid
4. Click "Add Listing" to save

### Finding Your Airbnb iCalendar URL

1. Log in to your Airbnb host account
2. Go to "Calendar" for the listing you want to add
3. Click on "Export Calendar" or "Calendar Settings"
4. Look for "iCal Link" or "Export Calendar"
5. Copy the URL provided (it should end with .ics)

### Using the Calendar

1. The main page shows your unified calendar with all listings
2. Use the checkboxes on the left to show/hide specific listings
3. Navigate between months using the forward and back buttons
4. Switch between month, week, and day views using the buttons at the top
5. Click "Sync Now" to refresh calendar data from Airbnb

### Managing Listings

1. Click on "Manage Listings" in the navigation menu
2. View all your added listings
3. Edit a listing by clicking "Edit"
4. Delete a listing by clicking "Delete"

## Troubleshooting

### Calendar Not Showing Events

- Make sure you've clicked "Sync Now" to fetch the latest data
- Verify that the iCalendar URL is correct and accessible
- Check that the listing is selected (checkbox checked) in the listings panel

### iCalendar URL Not Working

- Ensure you've copied the complete URL from Airbnb
- Try using the "Test Connection" button when adding or editing a listing
- Some iCalendar URLs may require a CORS proxy for access in a browser

### Data Not Saving

- The application uses your browser's local storage to save data
- Make sure you're not in private/incognito browsing mode
- Clearing browser data will remove your saved listings

## Technical Information

- This application runs entirely in your browser
- No data is sent to any external servers (except to fetch iCalendar data)
- Your listing information is stored in your browser's local storage
- The application uses a CORS proxy to access iCalendar data from Airbnb

## Support

If you encounter any issues or have questions about the application, please refer to the documentation or contact the developer.
