module.exports = { 
  output: 'export', 
  eslint: { 
    ignoreDuringBuilds: true 
  },
  images: {
    unoptimized: true
  }
}
